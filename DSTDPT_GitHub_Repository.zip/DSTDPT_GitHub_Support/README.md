# DSTDPT HOMO–LUMO Gap Prediction — Supporting Outputs

This package contains supporting outputs extracted from the saved results embedded in `DSTDPT(4).ipynb`.

## Contents
- `supporting_outputs/DSTDPT_Extracted_Notebook_Tables.xlsx`: tables rendered in the notebook outputs.
- `supporting_outputs/Figure_Index.csv`: index of extracted notebook figures.
- `supporting_outputs/Table_Index.csv`: index/provenance of extracted notebook tables.
- `supporting_outputs/README_extraction_notes.md`: extraction notes and limitations.

## Important data-availability limitation
The Excel workbook contains tables rendered in the notebook outputs. Some notebook outputs are previews (for example, `.head()` tables), not necessarily complete datasets. **This workbook must not be described as the complete 100-molecule dataset.**

The notebook code refers to external CSV files including:
- `clean_ML_dataset_100_molecules.csv`
- `clean_descriptor_matrix.csv`
- `07_xTB_HOMO_LUMO_results.csv`

Those complete CSV files were not embedded as full datasets in the uploaded notebook. They must be recovered from the original Colab runtime or Google Drive and added separately before claiming that all data needed to reproduce the results are publicly available.

## Reproduction
Include the original `.ipynb` notebook and the complete input CSV files in the repository. Add a `requirements.txt` containing the package versions actually used. Review the notebook from top to bottom in a fresh Colab runtime to ensure it runs using only repository files and does not depend on unavailable `/content` paths.
